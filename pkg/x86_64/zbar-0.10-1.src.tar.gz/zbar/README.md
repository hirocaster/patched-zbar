Forked by http://zbar.sourceforge.net/

Patched by https://gist.github.com/willglynn/5659946
